package com.tw.microservice.demo.repository;

import com.tw.microservice.demo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Integer> {
}
