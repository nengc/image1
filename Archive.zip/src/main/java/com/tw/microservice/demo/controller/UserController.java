package com.tw.microservice.demo.controller;

import com.tw.microservice.demo.controller.dto.UserDTO;
import com.tw.microservice.demo.service.UserService;
import com.tw.microservice.demo.service.request.CreateUserRequest;
import com.tw.microservice.demo.service.request.UpdateUserRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.NO_CONTENT;

@RestController
@RequestMapping("users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping
    public ResponseEntity<UserDTO> createUser(@Validated @RequestBody CreateUserRequest createUserRequest) {
        return ResponseEntity.status(CREATED).body(UserDTO.from(userService.create(createUserRequest)));
    }

    @GetMapping
    public List<UserDTO> getUsers() {
        return UserDTO.listFrom(userService.findAll());
    }

    @GetMapping("{id}")
    public UserDTO getUser(@PathVariable Integer id) {
        return UserDTO.from(userService.findById(id));
    }

    @PutMapping("{id}")
    public UserDTO updateUser(@PathVariable Integer id, @Validated @RequestBody UpdateUserRequest updateUserRequest) {
        return UserDTO.from(userService.update(id, updateUserRequest));
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Object> deleteUser(@PathVariable Integer id) {
        userService.deleteById(id);
        return ResponseEntity.status(NO_CONTENT).build();
    }
}
