CREATE TABLE IF NOT EXISTS user
(
    id         INT(11) AUTO_INCREMENT,
    name       VARCHAR(32) NOT NULL,
    age        INT(11)     NOT NULL,
    created_at DATETIME,
    updated_at DATETIME,
    PRIMARY KEY (id)
);