package com.tw.microservice.demo.model;

import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.Entity;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Getter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@ToString
public class User extends BasicEntity {

    @NotEmpty
    private String name;

    @NotNull
    private Integer age;

    public void update(String name, Integer age) {
        this.name = name;
        this.age = age;
    }
}
