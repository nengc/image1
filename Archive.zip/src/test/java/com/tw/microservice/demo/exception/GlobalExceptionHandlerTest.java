package com.tw.microservice.demo.exception;

import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpStatus.NOT_FOUND;

@ExtendWith(MockitoExtension.class)
class GlobalExceptionHandlerTest {

    private GlobalExceptionHandler globalExceptionHandler = new GlobalExceptionHandler();

    @Nested
    class HandleUserNotFoundExceptionTest {

        @Test
        void shouldReturn404() {
            String mockPath = "/mock";
            UserNotFoundException userNotFoundException = new UserNotFoundException();
            HttpServletRequest request = mock(HttpServletRequest.class);
            when(request.getRequestURI()).thenReturn(mockPath);

            ResponseEntity<Error> responseEntity = globalExceptionHandler.handleUserNotFoundException(userNotFoundException, request);

            assertThat(responseEntity.getStatusCode()).isEqualTo(NOT_FOUND);
        }
    }

}