package com.tw.microservice.demo.controller.dto;

import com.tw.microservice.demo.model.User;
import lombok.*;

import java.util.List;

import static java.util.stream.Collectors.toList;

@Getter
@Setter
@Builder
@EqualsAndHashCode
@ToString
public class UserDTO {

    private Integer id;
    private String name;
    private Integer age;

    public static List<UserDTO> listFrom(List<User> users) {
        return users.stream().map(UserDTO::from).collect(toList());
    }

    public static UserDTO from(User user) {
        return UserDTO.builder()
                .id(user.getId())
                .name(user.getName())
                .age(user.getAge())
                .build();
    }
}
