package com.tw.microservice.demo.exception;

import lombok.Getter;

@Getter
public class BasicException extends RuntimeException {

    private final String code;

    public BasicException(ErrorCode errorCode) {
        super(errorCode.getMessage());
        this.code = errorCode.getCode();
    }
}
