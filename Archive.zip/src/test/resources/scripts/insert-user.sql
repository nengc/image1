insert into user(name, age, created_at, updated_at)
values
  ('Jim', 18, now(), now());
