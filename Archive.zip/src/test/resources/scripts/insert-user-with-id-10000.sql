insert into user(id, name, age, created_at, updated_at)
values
  (10000, 'Jim', 18, now(), now());
