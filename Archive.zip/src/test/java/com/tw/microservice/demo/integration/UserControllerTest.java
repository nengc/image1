package com.tw.microservice.demo.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tw.microservice.demo.service.request.CreateUserRequest;
import com.tw.microservice.demo.service.request.UpdateUserRequest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.web.servlet.MockMvc;

import javax.transaction.Transactional;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional // 使用@Transcational注解，在测试方法结束后对数据库数据进行回滚
@ActiveProfiles("it")
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void shouldReturn201WhenCreateUserGivenValidRequest() throws Exception {
        String mockName = "Jim";
        int mockAge = 18;
        CreateUserRequest createUserRequest = CreateUserRequest.builder()
                .name(mockName)
                .age(mockAge)
                .build();

        mockMvc.perform(
                post("/users")
                        .accept(APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(createUserRequest))
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").isNumber())
                .andExpect(jsonPath("$.name").value(mockName))
                .andExpect(jsonPath("$.age").value(mockAge));
    }

    @Test
    void shouldReturn400WhenCreateUserGivenInvalidRequest() throws Exception {
        CreateUserRequest createUserRequest = CreateUserRequest.builder()
                .build();

        mockMvc.perform(
                post("/users")
                        .accept(APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(createUserRequest))
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    @Sql(scripts = "/scripts/insert-user.sql")
    void shouldReturn200WhenGetUsers() throws Exception {
        mockMvc.perform(
                get("/users")
                        .accept(APPLICATION_JSON)
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$[0].id").isNumber())
                .andExpect(jsonPath("$[0].name").isString())
                .andExpect(jsonPath("$[0].age").isNumber());
    }

    @Test
    @Sql(scripts = "/scripts/insert-user-with-id-10000.sql")
    void shouldReturn200WhenGetUserGivenExistedId() throws Exception {
        mockMvc.perform(
                get("/users/10000")
                        .accept(APPLICATION_JSON)
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").isNumber())
                .andExpect(jsonPath("$.name").isString())
                .andExpect(jsonPath("$.age").isNumber());
    }

    @Test
    void shouldReturn404WhenGetUserGivenNotExistedId() throws Exception {
        mockMvc.perform(
                get("/users/99999")
                        .accept(APPLICATION_JSON)
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    @Sql(scripts = "/scripts/insert-user-with-id-10000.sql")
    void shouldReturn200WhenUpdateUserGivenExistedId() throws Exception {
        String mockName = "Tom";
        int mockAge = 20;
        UpdateUserRequest updateUserRequest = UpdateUserRequest.builder()
                .name(mockName)
                .age(mockAge)
                .build();

        mockMvc.perform(
                put("/users/10000")
                        .accept(APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateUserRequest))
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").isNumber())
                .andExpect(jsonPath("$.name").value(mockName))
                .andExpect(jsonPath("$.age").value(mockAge));
    }

    @Test
    void shouldReturn404WhenUpdateUserGivenNotExistedId() throws Exception {
        String mockName = "Tom";
        int mockAge = 20;
        UpdateUserRequest updateUserRequest = UpdateUserRequest.builder()
                .name(mockName)
                .age(mockAge)
                .build();

        mockMvc.perform(
                put("/users/99999")
                        .accept(APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateUserRequest))
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    @Sql(scripts = "/scripts/insert-user-with-id-10000.sql")
    void shouldReturn204WhenDeleteUserGivenExistedId() throws Exception {
        mockMvc.perform(
                delete("/users/10000")
                        .accept(APPLICATION_JSON)
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    void shouldReturn404WhenDeleteUserGivenNotExistedId() throws Exception {
        mockMvc.perform(
                delete("/users/99999")
                        .accept(APPLICATION_JSON)
                        .contentType(APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }
}
