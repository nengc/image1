package com.tw.microservice.demo.controller;

import com.tw.microservice.demo.controller.dto.UserDTO;
import com.tw.microservice.demo.model.User;
import com.tw.microservice.demo.service.UserService;
import com.tw.microservice.demo.service.request.CreateUserRequest;
import com.tw.microservice.demo.service.request.UpdateUserRequest;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static java.util.Collections.singletonList;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpStatus.CREATED;
import static org.springframework.http.HttpStatus.NO_CONTENT;

@ExtendWith(MockitoExtension.class)
class UserControllerTest {

    @InjectMocks
    private UserController userController;

    @Mock
    private UserService userService;

    private Integer mockId = 1;
    private String mockName = "Tom";
    private Integer mockAge = 18;

    private User mockUser = User.builder()
            .id(mockId)
            .name(mockName)
            .age(mockAge)
            .build();

    private UserDTO mockUserDTO = UserDTO.from(mockUser);

    @Nested
    class CreateUserTest {

        private CreateUserRequest createUserRequest = CreateUserRequest.builder()
                .name(mockName)
                .age(mockAge)
                .build();

        @Test
        void shouldReturn201() {
            when(userService.create(createUserRequest)).thenReturn(mockUser);

            ResponseEntity<UserDTO> result = userController.createUser(createUserRequest);
            assertThat(result.getStatusCode()).isEqualTo(CREATED);
            assertThat(result.getBody()).isEqualTo(mockUserDTO);
        }
    }

    @Nested
    class GetUsersTest {

        @Test
        void shouldReturnAllUsers() {
            when(userService.findAll()).thenReturn(singletonList(mockUser));

            List<UserDTO> userDTOs = userController.getUsers();
            assertThat(userDTOs.size()).isOne();
            UserDTO userDTO = userDTOs.get(0);
            assertThat(userDTO).isEqualTo(mockUserDTO);
        }
    }

    @Nested
    class GetUserTest {

        @Test
        void shouldReturnFoundUser() {
            when(userService.findById(mockId)).thenReturn(mockUser);

            UserDTO userDTO = userController.getUser(mockId);
            assertThat(userDTO).isEqualTo(mockUserDTO);
        }
    }

    @Nested
    class UpdateUserTest {

        @Test
        void shouldReturnUpdatedUser() {
            UpdateUserRequest updateUserRequest = UpdateUserRequest.builder()
                    .name(mockName)
                    .age(mockAge)
                    .build();
            when(userService.update(mockId, updateUserRequest)).thenReturn(mockUser);

            UserDTO userDTO = userController.updateUser(mockId, updateUserRequest);
            assertThat(userDTO).isEqualTo(mockUserDTO);
        }
    }

//    @Nested
//    class DeleteUserTest {
//
//        @Test
//        void shouldReturn204() {
//            doNothing().when(userService).deleteById(mockId);
//
//            ResponseEntity<Object> result = userController.deleteUser(mockId);
//            assertThat(result.getStatusCode()).isEqualTo(NO_CONTENT);
//        }
//    }

}
