package com.tw.microservice.demo.exception;

import lombok.Builder;
import lombok.Getter;

import java.util.Date;

@Builder
@Getter
public class Error {
    private String code;
    private String message;
    private Object data;
    private String traceId;
    private Date timestamp;
    private String path;
}
