package com.tw.microservice.demo.exception;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.http.HttpServletRequest;

import java.util.Date;

@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    private static final String B3_TRACE_ID = "X-B3-TraceId";

    @ExceptionHandler({UserNotFoundException.class})
    public ResponseEntity<Error> handleUserNotFoundException(UserNotFoundException exception, HttpServletRequest request) {
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(process(exception, request, exception.getCode(), exception.getMessage()));
    }

    private Error process(Exception exception, HttpServletRequest request, String code, String message) {
        log.error("[Error occurred.] - [] - [code={}, message={}] - []", code, exception.getMessage());
        return Error.builder()
                .code(code)
                .message(message)
                .data(exception.getMessage())
                .traceId(MDC.get(B3_TRACE_ID))
                .timestamp(new Date())
                .path(request.getRequestURI())
                .build();
    }
}
