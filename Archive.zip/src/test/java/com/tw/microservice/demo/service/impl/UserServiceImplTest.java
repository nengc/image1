package com.tw.microservice.demo.service.impl;

import com.tw.microservice.demo.exception.UserNotFoundException;
import com.tw.microservice.demo.model.User;
import com.tw.microservice.demo.repository.UserRepository;
import com.tw.microservice.demo.service.request.CreateUserRequest;
import com.tw.microservice.demo.service.request.UpdateUserRequest;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.EmptyResultDataAccessException;

import java.util.List;
import java.util.Optional;

import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    @InjectMocks
    private UserServiceImpl userService;

    @Mock
    private UserRepository userRepository;


    private Integer mockId = 1;
    private String mockName = "Tom";
    private Integer mockAge = 18;

    private User mockUser = User.builder()
            .id(mockId)
            .name(mockName)
            .age(mockAge)
            .build();

    @Nested
    class CreateTest {

        private final CreateUserRequest createUserRequest = CreateUserRequest.builder()
                .name(mockName)
                .age(mockAge)
                .build();

        @Test
        void shouldCreateUserGivenValidRequest() {
            when(userRepository.save(any(User.class))).thenReturn(mockUser);

            User user = userService.create(createUserRequest);
            assertThat(user.getId()).isEqualTo(mockUser.getId());
            assertThat(user.getName()).isEqualTo(mockUser.getName());
            assertThat(user.getAge()).isEqualTo(mockUser.getAge());
        }
    }

    @Nested
    class FindAllTest {

        @Test
        void shouldReturnAllUsers() {
            when(userRepository.findAll()).thenReturn(singletonList(mockUser));

            List<User> users = userService.findAll();

            assertThat(users.size()).isOne();

            User user = users.get(0);
            assertThat(user.getId()).isEqualTo(mockUser.getId());
            assertThat(user.getName()).isEqualTo(mockUser.getName());
            assertThat(user.getAge()).isEqualTo(mockUser.getAge());
        }
    }

    @Nested
    class FindByIdTest {

        @Test
        void shouldThrowUserNotFoundExceptionGivenNotExistedId() {
            when(userRepository.findById(mockId)).thenReturn(Optional.empty());
            assertThatThrownBy(() -> userService.findById(mockId)).isInstanceOf(UserNotFoundException.class);
        }

        @Test
        void shouldReturnFoundUserGivenExistedId() {
            when(userRepository.findById(mockId)).thenReturn(Optional.of(mockUser));

            User user = userService.findById(mockId);
            assertThat(user.getId()).isEqualTo(mockUser.getId());
            assertThat(user.getId()).isEqualTo(mockUser.getId());
            assertThat(user.getName()).isEqualTo(mockUser.getName());
            assertThat(user.getAge()).isEqualTo(mockUser.getAge());
        }
    }

    @Nested
    class UpdateTest {

        UpdateUserRequest updateUserRequest = UpdateUserRequest.builder()
                .name(mockName)
                .age(mockAge)
                .build();

        @Test
        void shouldThrowUserNotFoundExceptionGivenNotExistedId() {
            when(userRepository.findById(mockId)).thenReturn(Optional.empty());
            assertThatThrownBy(() -> userService.update(mockId, updateUserRequest)).isInstanceOf(UserNotFoundException.class);
        }

        @Test
        void shouldReturnUpdatedUserGivenValidRequest() {
            when(userRepository.findById(mockId)).thenReturn(Optional.of(mockUser));
            when(userRepository.save(any(User.class))).thenReturn(mockUser);

            User user = userService.update(mockId, updateUserRequest);
            assertThat(user).isEqualTo(mockUser);
        }
    }

    @Nested
    class DeleteByIdTest {

        @Test
        void shouldThrowUserNotFoundExceptionGivenNotExistedId() {
            doThrow(new EmptyResultDataAccessException(mockId)).when(userRepository).deleteById(mockId);
            assertThatThrownBy(() -> userService.deleteById(mockId)).isInstanceOf(UserNotFoundException.class);
        }

        @Test
        void shouldDeleteRoleGivenValidId() {
            doNothing().when(userRepository).deleteById(mockId);
            userService.deleteById(mockId);

            verify(userRepository, times(1)).deleteById(mockId);
        }
    }
}
