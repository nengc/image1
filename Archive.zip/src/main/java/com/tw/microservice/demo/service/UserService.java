package com.tw.microservice.demo.service;

import com.tw.microservice.demo.model.User;
import com.tw.microservice.demo.service.request.CreateUserRequest;
import com.tw.microservice.demo.service.request.UpdateUserRequest;

import java.util.List;

public interface UserService {

    User create(CreateUserRequest createUserRequest);

    List<User> findAll();

    User findById(Integer id);

    User update(Integer id, UpdateUserRequest updateUserRequest);

    void deleteById(Integer id);
}
