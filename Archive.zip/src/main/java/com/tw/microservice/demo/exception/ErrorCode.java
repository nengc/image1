package com.tw.microservice.demo.exception;

import lombok.Getter;

@Getter
public enum ErrorCode {
    USER_NOT_FOUND("0101001", "User Not Found");

    private String code;
    private String message;

    ErrorCode(String code, String message) {
        this.code = code;
        this.message = message;
    }
}
