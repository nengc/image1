package com.tw.microservice.demo.service.impl;

import com.tw.microservice.demo.exception.UserNotFoundException;
import com.tw.microservice.demo.model.User;
import com.tw.microservice.demo.repository.UserRepository;
import com.tw.microservice.demo.service.UserService;
import com.tw.microservice.demo.service.request.CreateUserRequest;
import com.tw.microservice.demo.service.request.UpdateUserRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    @Override
    public User create(CreateUserRequest createUserRequest) {
        User user = User.builder()
                .name(createUserRequest.getName())
                .age(createUserRequest.getAge())
                .build();
        return userRepository.save(user);
    }

    @Override
    public List<User> findAll() {
        return userRepository.findAll();
    }

    @Override
    public User findById(Integer id) {
        return userRepository.findById(id).orElseThrow(UserNotFoundException::new);
    }

    @Override
    @Transactional
    public User update(Integer id, UpdateUserRequest updateUserRequest) {
        User user = userRepository.findById(id).orElseThrow(UserNotFoundException::new);
        user.update(updateUserRequest.getName(), updateUserRequest.getAge());
        return userRepository.save(user);
    }

    @Override
    public void deleteById(Integer id) {
        try {
            log.info("[Deleting use by id] - [userId={}] - [] - []", id);
            userRepository.deleteById(id);
        } catch (EmptyResultDataAccessException ex) {
            throw new UserNotFoundException();
        }
    }
}
